'use client'

import { useEffect, useState } from 'react'

const ecosystem = [
  ['Real Estate Developers', 'Handover, community setup, portfolio performance across projects.'],
  ['Property Managers', 'Leases, service charges, collections, renewals, communication.'],
  ['Facility Management', 'Asset registers, planned maintenance, inspections, compliance.'],
  ['Maintenance Providers', 'Work orders, dispatch, SLAs, parts, completion sign-off.'],
  ['Community Management', 'Owners associations, budgets, announcements, governance.'],
  ['Operations Teams', 'Daily workflow, escalations, staffing, service quality.'],
  ['Owners & Investors', 'Occupancy, yield, cost per unit, operational reporting.'],
  ['Residents & Clients', 'Requests, payments, documents, updates — one channel.'],
]

const lifecycle = [
  ['Handover', 'Snagging, documentation, unit data, warranty capture'],
  ['Community', 'Associations, budgets, governance, announcements'],
  ['Facility', 'Assets, PPM schedules, inspections, compliance'],
  ['Maintenance', 'Requests, dispatch, SLA tracking, resolution'],
  ['Experience', 'Resident portal, payments, documents, service'],
  ['Intelligence', 'Cost, performance, benchmarking, decisions'],
]

const pillars = [
  ['01', 'Visibility', 'You cannot operate what you cannot see. Pilot makes the current state of a property visible to everyone entitled to see it.'],
  ['02', 'Control', 'Operations move from reactive to deliberate. Work is scheduled, tracked and closed — not remembered.'],
  ['03', 'Confidence', 'Decisions are made on current information, so they can be defended in a board meeting and in an audit.'],
  ['04', 'Connection', 'Developers, managers, contractors and residents work from one shared record instead of four private versions of the truth.'],
  ['05', 'Intelligence', 'Daily operations generate the data that improves them. The system gets more valuable the longer it runs.'],
]

function Mark({ reversed = false }: { reversed?: boolean }) {
  return <span className={`pilot-mark ${reversed ? 'is-reversed' : ''}`} aria-hidden="true"><i /></span>
}

function Reveal({ children, className = '' }: { children: React.ReactNode; className?: string }) {
  return <div className={`reveal ${className}`}>{children}</div>
}

export default function Page() {
  const [active, setActive] = useState(false)
  useEffect(() => { requestAnimationFrame(() => setActive(true)) }, [])

  return (
    <main className={active ? 'page is-ready' : 'page'}>
      <nav className="nav shell" aria-label="Primary navigation">
        <a className="wordmark" href="#top" aria-label="Pilot home"><Mark /><span>PILOT</span></a>
        <div className="nav-meta"><a href="#ecosystem">The ecosystem</a><a href="#mission">Mission</a><a className="nav-contact" href="mailto:hello@pilot.com">Contact <span>↗</span></a></div>
      </nav>

      <section id="top" className="hero shell">
        <div className="hero-grid" />
        <div className="eyebrow"><span className="signal-dot" /> Property Operations Technology <span className="hero-index">001 / 014</span></div>
        <div className="hero-copy">
          <Reveal><h1>The infrastructure<br />behind <em>better</em><br />property operations.</h1></Reveal>
          <Reveal className="hero-support"><p>We build the digital infrastructure that powers modern property operations.</p><a className="text-link" href="#ecosystem">Explore the ecosystem <span>↓</span></a></Reveal>
        </div>
        <div className="hero-device" aria-hidden="true">
          <div className="hero-orbit orbit-one" />
          <div className="hero-orbit orbit-two" />
          <div className="hero-orbit orbit-three" />
          <div className="hero-core"><Mark reversed /><span>PILOT</span></div>
          <div className="hero-coordinate">25° 12′ N<br />55° 16′ E</div>
        </div>
        <div className="hero-foot"><span>Visibility</span><span>Control</span><span>Confidence</span><span className="scroll-cue">Scroll to operate <b>↓</b></span></div>
      </section>

      <section className="dark-band statement"><div className="shell statement-inner"><span className="section-no">02</span><Reveal><p className="display">Pilot is a Property Operations Technology Company.</p></Reveal><p className="body-copy">Our technology helps real estate developers, property managers, and facility management companies operate their properties with greater visibility, control, and confidence.</p><div className="statement-rule" /><p className="body-copy muted">From community management and facility operations to resident experiences and operational intelligence, Pilot transforms fragmented processes into one connected ecosystem.</p></div></section>

      <section id="ecosystem" className="light-section ecosystem shell"><div className="section-header"><span className="section-no">03</span><div><span className="eyebrow">The Ecosystem</span><h2>One platform,<br /><em>every party.</em></h2></div><p>Property operations are not a single company's problem. They are a chain of organisations that must agree with each other continuously. Pilot is the layer they all operate on.</p></div><div className="network"><svg className="network-lines" viewBox="0 0 1000 580" preserveAspectRatio="none" aria-hidden="true"><path d="M190 88 H350 V290 H425 M190 255 H350 V290 H425 M190 422 H350 V290 H425 M190 504 H350 V290 H425 M810 88 H650 V290 H575 M810 255 H650 V290 H575 M810 422 H650 V290 H575 M810 504 H650 V290 H575" /></svg><div className="network-core"><Mark reversed /><span>Pilot</span><small>Shared operational record</small></div>{ecosystem.map(([title, text], i) => <Reveal className={`node node-${i + 1}`} key={title}><span className="node-dot" /><strong>{title}</strong><small>{text}</small></Reveal>)}</div></section>

      <section className="paper-section shell"><div className="section-header split"><span className="section-no">04</span><div><span className="eyebrow">What We Connect</span><h2>From fragmented processes to <em>one connected ecosystem.</em></h2></div><p>The operational journey does not begin at handover and it does not end at occupancy. Pilot spans the entire operating life of a property.</p></div><div className="lifecycle">{lifecycle.map(([title, text], i) => <Reveal className="life-item" key={title}><span className="life-no">0{i + 1}</span><strong>{title}</strong><span>{text}</span></Reveal>)}</div></section>

      <section id="mission" className="dark-band vision"><div className="shell vision-inner"><div className="vision-aside"><span className="section-no">05</span><span className="eyebrow">Vision</span><div className="vision-stamp" aria-hidden="true">V</div></div><div className="vision-main"><Reveal><h2>To become the digital infrastructure behind the world's most trusted property operations.</h2></Reveal><div className="vision-bottom"><p>We envision a future where every residential community, commercial property, and mixed-use development operates through a connected, intelligent platform that enables better decisions, better experiences, and better outcomes.</p><div className="vision-signal"><span>Operating life / 01—∞</span><div className="signal-track"><i /></div></div></div></div></div></section>

      <section className="paper-section shell mission"><div className="section-header split"><span className="section-no">06</span><div><span className="eyebrow">Mission</span><h2>To simplify, connect, and elevate property operations through intelligent technology.</h2></div><p>We empower real estate organizations with scalable digital solutions that improve operational efficiency, enhance customer experiences, and grow alongside their business — from their first project to large-scale portfolios.</p></div><div className="pillar-list">{pillars.slice(0, 3).map(([no, title, text]) => <Reveal className="pillar" key={no}><span>{no}</span><h3>{title}</h3><p>{text}</p></Reveal>)}</div></section>

      <section className="dark-band final"><div className="shell final-inner"><Mark reversed /><Reveal><h2>Great properties are not defined only by how they are built.<br /><em>They are defined by how they are operated.</em></h2></Reveal><a className="outline-link" href="mailto:hello@pilot.com">Start a conversation <span>↗</span></a><footer><span>© 2026 Pilot</span><span>Property Operations Technology</span><span>Built for the operating life of a property.</span></footer></div></section>
    </main>
  )
}
